/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.testando.carro;

import java.rmi.server.RemoteStub;

/**
 *
 * @author Abner
 */
public class Transmissao {
    private int marchaAtual;
    private boolean estado;

  

    public int getMarchaAtual() {
        return marchaAtual;
    }

    public void setMarchaAtual(int marchaAtual) {
        this.marchaAtual = marchaAtual;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }







    public void aumentarMarcha() {
        if (marchaAtual < 6) {
            marchaAtual++;
            System.out.println("Marcha aumentada para " + marchaAtual);
        } else {
            System.out.println("Não é possível aumentar mais!");
        }
    }

}
