
package com.testando.carro;

/**
 *
 * @author Abner
 */
public class Painel {
    public String exibirStatus() {
        return "Motor ligado\nTransmissão ativa\nSistema elétrico funcionando\nPronto para acelerar o carro";
    }
}
