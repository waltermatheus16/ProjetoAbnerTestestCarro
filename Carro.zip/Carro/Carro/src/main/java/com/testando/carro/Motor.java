
package com.testando.carro;

/**
 *
 * @author Abner
 */
public class Motor {
    
    
    private String tipo;
    private String potencia;
    private double cilindrado;
    private String marca;
    private String estado;




    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPotencia() {
        return potencia;
    }

    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    public double getCilindrado() {
        return cilindrado;
    }

    public void setCilindrado(double cilindrado) {
        this.cilindrado = cilindrado;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
        
    

    public boolean verificarestadoMotor(Transmissao transmissao , SistemaEletrico sistemaEletrico ){

        return transmissao.isEstado() && sistemaEletrico.isEstado();


    }




    public void ligarMotor(Transmissao transmissao , SistemaEletrico sistemaEletrico){

        if (verificarestadoMotor(transmissao , sistemaEletrico){

            System.out.println("Motor ligado");

        }

        if (verificarestadoMotor(transmissao , sistemaEletrico){

            System.out.println("Motor ligado");

        }   


        
    }

    public void desligarMotor(){
        System.out.println("Motor desligado");
        
    }

   


    
    }

